# SkillBridge

SkillBridge is a PHP/MySQL career guidance, job, internship and recruitment platform.

## Technologies
- PHP 8 + PDO
- MySQL / MariaDB
- HTML5 + CSS3 + JavaScript
- XAMPP / Apache
- Server-rendered dynamic charts (no chart CDN required)
- Explainable rule-based recommendation and classifier demonstration
- Cybersecurity controls: password hashing, prepared statements, CSRF, XSS escaping, role-based access, login throttling, security logs

## Install
1. Copy folder `skilledbridge` to `C:\xampp\htdocs\`.
2. Start Apache and MySQL.
3. Create database `skilledbridge` in phpMyAdmin.
4. Import `sql/skilledbridge.sql`.
5. Open `http://localhost/skilledbridge/`.

## Demo accounts
- Admin: ADM100001 / admin123!
- Student: STD100001 / student123!
- Employer: EMP100001 / employer123!
- Counselor: CNS100001 / counselor123!
- 
## Important academic statement
The AI and machine-learning modules are transparent educational prototypes used for job matching, resume analysis, and skill-gap analysis.
