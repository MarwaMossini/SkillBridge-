<?php
$title='Resume analysis';require '../partials/header.php';require_role('student');$uid=user()['id'];
$p=$pdo->prepare('SELECT * FROM student_profiles WHERE user_id=?');$p->execute([$uid]);$p=$p->fetch();
$s=$pdo->prepare('SELECT COUNT(*) FROM student_skills WHERE student_id=?');$s->execute([$uid]);$skillCount=(int)$s->fetchColumn();
$r=$pdo->prepare('SELECT * FROM resumes WHERE student_id=? ORDER BY uploaded_at DESC,id DESC LIMIT 1');$r->execute([$uid]);$resume=$r->fetch();
$text=$resume['extracted_text']??($p['resume_summary']??'');
$detected=array_filter(array_map('trim',explode(',',$resume['detected_skills']??'')));
$checks=[
 ['Resume uploaded',!empty($resume),15],
 ['Readable resume text',mb_strlen($text)>=200,15],
 ['Education section',preg_match('/education|university|college|degree|bachelor|master/i',$text),15],
 ['Experience or internship',preg_match('/experience|employment|intern|work history/i',$text),20],
 ['Projects / portfolio',preg_match('/project|portfolio|github/i',$text),15],
 ['Measurable achievements',preg_match('/\b\d+%|\b\d+\+|\b\d+\s*(years?|months?)\b/i',$text),10],
 ['Detected or recorded skills',count($detected)>=3||$skillCount>=4,10]
];
$score=0;foreach($checks as $c)if($c[1])$score+=$c[2];
?>
<div class="sidebar-layout"><?php include 'nav.php';?><section><h1>AI-assisted resume analysis</h1><div class="notice">SkillBridge reads the latest uploaded resume and performs transparent rule-based analysis. It does not guarantee ATS acceptance or hiring.</div>
<?php if(!$resume):?><div class="section card"><h2>No resume uploaded yet</h2><p>Upload a resume first so the system can read and analyze it.</p><a class="btn" href="resume.php">Upload resume</a></div><?php else:?><div class="section grid two"><div class="card"><div class="score"><?=$score?>%</div><h2>Resume readiness score</h2><p><?=e($resume['original_name'])?></p><div class="progress"><i style="width:<?=$score?>%"></i></div><p><b>Detected skills:</b> <?=e($resume['detected_skills']?:'No known skills detected')?></p></div><div class="card"><h2>Analysis results</h2><?php foreach($checks as $c):?><p><?=$c[1]?'✓':'△'?> <b><?=e($c[0])?></b> — <?=$c[1]?'Found':'Needs improvement'?></p><?php endforeach;?></div></div>
<div class="section card"><h2>Recommended next steps</h2><p><?php $tips=[];foreach($checks as $c)if(!$c[1])$tips[]=$c[0];?>Focus on: <?=e(implode(', ',$tips)?:'Your resume has the main elements. Tailor it to each job and keep achievements specific.')?></p><a class="btn" href="resume.php">Upload updated resume</a></div><?php endif;?></section></div><?php require '../partials/footer.php';?>
