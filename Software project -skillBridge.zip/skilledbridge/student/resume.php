<?php
$title='Upload resume';
require '../partials/header.php';
require_role('student');
$uid=user()['id'];

function extract_docx_text($path){
    if(!class_exists('ZipArchive')) return '';
    $zip=new ZipArchive();
    if($zip->open($path)!==true) return '';
    $xml=$zip->getFromName('word/document.xml');
    $zip->close();
    if(!$xml) return '';
    $xml=preg_replace('/<w:tab[^>]*\/>/','\t',$xml);
    $xml=preg_replace('/<w:br[^>]*\/>/','\n',$xml);
    $xml=preg_replace('/<\/w:p>/','\n',$xml);
    return trim(html_entity_decode(strip_tags($xml),ENT_QUOTES|ENT_XML1,'UTF-8'));
}
function detect_resume_skills($pdo,$text){
    $skills=$pdo->query('SELECT name FROM skills ORDER BY CHAR_LENGTH(name) DESC')->fetchAll(PDO::FETCH_COLUMN);
    $found=[];
    foreach($skills as $skill){
        if($skill!=='' && preg_match('/(?<![A-Za-z0-9])'.preg_quote($skill,'/').'(?![A-Za-z0-9])/iu',$text)) $found[]=$skill;
    }
    return array_values(array_unique($found));
}
function resume_score($text,$skills){
    $score=0;
    $len=mb_strlen($text);
    if($len>=500)$score+=15; elseif($len>=200)$score+=8;
    if(preg_match('/education|university|college|degree|bachelor|master/i',$text))$score+=15;
    if(preg_match('/experience|employment|intern|work history/i',$text))$score+=20;
    if(preg_match('/project|portfolio|github/i',$text))$score+=15;
    if(preg_match('/\b\d+%|\b\d+\+|\b\d+\s*(years?|months?)\b/i',$text))$score+=15;
    if(count($skills)>=3)$score+=20; elseif(count($skills)>=1)$score+=10;
    return min(100,$score);
}

if($_SERVER['REQUEST_METHOD']==='POST'){
    verify_csrf();
    $clientText=trim($_POST['extracted_text']??'');
    if(empty($_FILES['resume']) || $_FILES['resume']['error']!==UPLOAD_ERR_OK){
        flash('err','Choose a resume file first.');
        header('Location: resume.php');exit;
    }
    $file=$_FILES['resume'];
    if($file['size']>5*1024*1024){flash('err','Resume must be 5 MB or smaller.');header('Location: resume.php');exit;}
    $ext=strtolower(pathinfo($file['name'],PATHINFO_EXTENSION));
    $allowed=['pdf','docx','txt'];
    if(!in_array($ext,$allowed,true)){flash('err','Use PDF, DOCX or TXT format.');header('Location: resume.php');exit;}
    $finfo=new finfo(FILEINFO_MIME_TYPE);$mime=$finfo->file($file['tmp_name'])?:'application/octet-stream';
    $validMime=['application/pdf','application/vnd.openxmlformats-officedocument.wordprocessingml.document','application/zip','text/plain','application/octet-stream'];
    if(!in_array($mime,$validMime,true)){flash('err','The uploaded file type is not allowed.');header('Location: resume.php');exit;}
    $dir=dirname(__DIR__).'/uploads/resumes';
    if(!is_dir($dir))mkdir($dir,0755,true);
    $stored=bin2hex(random_bytes(16)).'.'.$ext;
    $dest=$dir.'/'.$stored;
    if(!move_uploaded_file($file['tmp_name'],$dest)){flash('err','Could not save the resume.');header('Location: resume.php');exit;}
    $text=$clientText;
    if($ext==='txt')$text=trim(file_get_contents($dest));
    if($ext==='docx')$text=extract_docx_text($dest) ?: $clientText;
    $text=preg_replace('/[ \t]+/',' ',str_replace("\r",'',(string)$text));
    $text=preg_replace('/\n{3,}/',"\n\n",$text);
    $skills=detect_resume_skills($pdo,$text);
    $score=resume_score($text,$skills);
    $st=$pdo->prepare('INSERT INTO resumes(student_id,original_name,stored_path,mime_type,file_size,extracted_text,detected_skills,analysis_score) VALUES(?,?,?,?,?,?,?,?)');
    $st->execute([$uid,$file['name'],'uploads/resumes/'.$stored,$mime,$file['size'],$text,implode(', ',$skills),$score]);
    log_event($pdo,'resume_uploaded','Student uploaded resume '.$file['name'],'info');
    flash('ok',$text!==''?'Resume uploaded and read successfully.':'Resume uploaded. Text extraction was not available for this file.');
    header('Location: resume.php');exit;
}
$st=$pdo->prepare('SELECT * FROM resumes WHERE student_id=? ORDER BY uploaded_at DESC,id DESC');$st->execute([$uid]);$rows=$st->fetchAll();$latest=$rows[0]??null;
?>
<div class="sidebar-layout"><?php include 'nav.php';?><section>
<?php if($m=flash('ok')):?><div class="alert success"><?=e($m)?></div><?php endif;?>
<?php if($m=flash('err')):?><div class="alert error"><?=e($m)?></div><?php endif;?>
<div class="card"><h1>Upload & read your resume</h1><p class="muted">Upload a PDF, DOCX or TXT resume. SkillBridge extracts readable text, detects skills already known to the platform, and uses the latest resume in your analysis and recommendations.</p>
<form method="post" enctype="multipart/form-data" id="resumeForm"><input type="hidden" name="csrf" value="<?=csrf()?>"><input type="hidden" name="extracted_text" id="extractedText">
<div class="form-grid"><div class="full"><label>Resume file</label><input type="file" id="resumeFile" name="resume" accept=".pdf,.docx,.txt,application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document,text/plain" required><small>Maximum 5 MB. PDF text is read in your browser before upload; DOCX/TXT are read on the server.</small></div>
<div class="full"><div id="readStatus" class="notice">Choose a file. SkillBridge will attempt to read its text automatically.</div></div>
<div class="full"><button type="submit">Upload and analyze resume</button></div></div></form></div>
<?php if($latest):?><div class="section grid two"><div class="card"><div class="score"><?=e($latest['analysis_score'])?>%</div><h2>Latest resume readiness</h2><p><b><?=e($latest['original_name'])?></b></p><p class="muted">Uploaded <?=e($latest['uploaded_at'])?></p><p><b>Detected skills:</b> <?=e($latest['detected_skills']?:'No platform skills detected yet')?></p><a class="btn" href="resume_analysis.php">Open resume analysis</a></div><div class="card"><h2>What the reader found</h2><div class="resume-preview"><?=nl2br(e(mb_substr($latest['extracted_text']??'',0,1600)))?><?=mb_strlen($latest['extracted_text']??'')>1600?'…':''?></div></div></div><?php endif;?>
<div class="section card"><h2>Resume history</h2><div class="table-wrap"><table><tr><th>File</th><th>Uploaded</th><th>Score</th><th>Detected skills</th></tr><?php foreach($rows as $r):?><tr><td><?=e($r['original_name'])?></td><td><?=e($r['uploaded_at'])?></td><td><?=e($r['analysis_score'])?>%</td><td><?=e($r['detected_skills']?:'—')?></td></tr><?php endforeach;?><?php if(!$rows):?><tr><td colspan="4">No resume uploaded yet.</td></tr><?php endif;?></table></div></div>
</section></div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js"></script>
<script>
(function(){
 const input=document.getElementById('resumeFile'), hidden=document.getElementById('extractedText'), status=document.getElementById('readStatus'), form=document.getElementById('resumeForm');
 let ready=true;
 if(window.pdfjsLib){pdfjsLib.GlobalWorkerOptions.workerSrc='https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';}
 input.addEventListener('change',async()=>{
   hidden.value=''; ready=true; const f=input.files[0]; if(!f)return;
   const ext=(f.name.split('.').pop()||'').toLowerCase();
   if(ext==='pdf'){
     if(!window.pdfjsLib){status.textContent='PDF selected. The file can be uploaded, but browser text-reading needs an internet connection for the PDF reader library.';return;}
     ready=false; status.textContent='Reading PDF text…';
     try{const data=new Uint8Array(await f.arrayBuffer());const pdf=await pdfjsLib.getDocument({data}).promise;let text='';for(let i=1;i<=pdf.numPages;i++){const p=await pdf.getPage(i);const c=await p.getTextContent();text+=c.items.map(x=>x.str).join(' ')+'\n';}hidden.value=text.trim();status.textContent='PDF read successfully: '+text.trim().length+' characters extracted.';}catch(e){status.textContent='Could not extract PDF text automatically. The file can still be uploaded.';}finally{ready=true;}
   }else if(ext==='docx'){status.textContent='DOCX selected. It will be read securely by PHP after upload.';}else if(ext==='txt'){status.textContent='TXT selected. It will be read securely by PHP after upload.';}
 });
 form.addEventListener('submit',e=>{if(!ready){e.preventDefault();status.textContent='Please wait until resume reading finishes.';}});
})();
</script>
<?php require '../partials/footer.php';?>
