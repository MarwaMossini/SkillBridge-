<aside class="student-tools" aria-label="Student workspace">
  <h3>Student workspace</h3>
  <div class="student-tool-grid">
    <a class="student-tool" href="<?=base_url('student/dashboard.php')?>"><span class="tool-icon">⌂</span><span>Overview</span></a>
    <a class="student-tool" href="<?=base_url('student/profile.php')?>"><span class="tool-icon">👤</span><span>Edit profile</span></a>
    <a class="student-tool" href="<?=base_url('student/skills.php')?>"><span class="tool-icon">✓</span><span>Skills</span></a>
    <a class="student-tool" href="<?=base_url('student/resume.php')?>"><span class="tool-icon">⇧</span><span>Upload resume</span></a>
    <a class="student-tool" href="<?=base_url('student/recommendations.php')?>"><span class="tool-icon">✦</span><span>Job recommendations</span></a>
    <a class="student-tool" href="<?=base_url('student/resume_analysis.php')?>"><span class="tool-icon">▤</span><span>Resume analysis</span></a>
    <a class="student-tool" href="<?=base_url('student/applications.php')?>"><span class="tool-icon">↗</span><span>My applications</span></a>
    <a class="student-tool" href="<?=base_url('student/counselors.php')?>"><span class="tool-icon">☏</span><span>Career counselors</span></a>
  </div>
</aside>