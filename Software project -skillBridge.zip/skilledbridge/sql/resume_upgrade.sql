USE skilledbridge;
CREATE TABLE IF NOT EXISTS resumes(
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  original_name VARCHAR(255) NOT NULL,
  stored_path VARCHAR(255) NOT NULL,
  mime_type VARCHAR(120),
  file_size INT DEFAULT 0,
  extracted_text MEDIUMTEXT,
  detected_skills TEXT,
  analysis_score INT DEFAULT 0,
  uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(student_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX(student_id, uploaded_at)
);
