# Team contribution guide
Use feature branches and meaningful commits.
1. UI/home/about/FAQ
2. Authentication/security
3. Student/AI/skills/applications
4. Employer/counselor/5. Admin/database/reports
Do not rewrite commit history to misrepresent contribution. Each member should commit changes they actually understand and can present.
