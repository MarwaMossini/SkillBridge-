<?php
if(session_status()!==PHP_SESSION_ACTIVE) session_start();
require_once __DIR__.'/db.php';
function e($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
function base_url($path=''){ $base=rtrim(str_replace('\\','/',dirname($_SERVER['SCRIPT_NAME'])),'/'); if(preg_match('#/(admin|student|employer|counselor|reports|security|ai)$#',$base)) $base=dirname($base); return $base.'/'.ltrim($path,'/'); }
function csrf(){ if(empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(24)); return $_SESSION['csrf']; }
function verify_csrf(){ if(!hash_equals($_SESSION['csrf']??'',$_POST['csrf']??'')) exit('Invalid request token.'); }
function user(){return $_SESSION['user']??null;}
function require_login(){if(!user()){header('Location: '.base_url('login.php'));exit;}}
function require_role($roles){require_login(); $roles=(array)$roles; if(!in_array(user()['role'],$roles,true)){http_response_code(403);exit('Access denied for this account role.');}}
function redirect_dashboard(){ $u=user(); if(!$u) return; $map=['admin'=>'admin/dashboard.php','student'=>'student/dashboard.php','employer'=>'employer/dashboard.php','counselor'=>'counselor/dashboard.php']; header('Location: '.base_url($map[$u['role']]??'index.php'));exit; }
function flash($k,$v=null){ if($v!==null){$_SESSION['flash'][$k]=$v;return;} $x=$_SESSION['flash'][$k]??null; unset($_SESSION['flash'][$k]); return $x; }
function bar_chart($rows,$labelKey,$valueKey,$max=0){ if(!$rows) return '<div class="empty">No data yet.</div>'; if(!$max) $max=max(array_column($rows,$valueKey))?:1; $html='<div class="bar-chart">'; foreach($rows as $r){$v=(float)$r[$valueKey];$pct=max(3,round($v/$max*100));$html.='<div class="bar-row"><span>'.e($r[$labelKey]).'</span><div class="bar-track"><div class="bar-fill" style="width:'.$pct.'%"></div></div><b>'.e($v).'</b></div>'; } return $html.'</div>'; }
function status_badge($s){return '<span class="badge status-'.e(strtolower($s)).'">'.e(ucfirst($s)).'</span>';}
function log_event($pdo,$type,$details,$severity='info'){try{$st=$pdo->prepare('INSERT INTO security_logs(user_id,event_type,details,severity,ip_address) VALUES(?,?,?,?,?)');$st->execute([user()['id']??null,$type,$details,$severity,$_SERVER['REMOTE_ADDR']??'local']);}catch(Throwable $e){}}
